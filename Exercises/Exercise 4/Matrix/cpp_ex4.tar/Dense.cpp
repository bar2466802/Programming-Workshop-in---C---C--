//
// Created by BarM on 6/17/2020.
//

#include "Dense.h"

Dense::Dense(const Matrix w, const Matrix bias, const ActivationType actType): _bias(bias),
		_weights(w), _act(actType)
{

}

Activation Dense::getActivation() const
{
	return _act;
}

Matrix Dense::getBias() const
{
	return _bias;
}

Matrix Dense::getWeights() const
{
	return _weights;
}

Matrix Dense::operator()(const Matrix &r) const
{
	//	int biosSize = b.getRows();
	//	switch(biosSize)
	//	{
	//		case FIRST:
	//		case SECOND:
	//		case THIRD:
	//		case FOURTH:
	//	}
	Matrix output = _act(((_weights * r) + _bias));
	return output;
}

