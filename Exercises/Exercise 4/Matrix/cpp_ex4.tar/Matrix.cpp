//
// Created by BarM on 6/17/2020.
//

#include "Matrix.h"

Matrix::Matrix(int rows, int cols):  _rows(rows), _cols(cols), _matrix(new float[rows * cols])
{
	for(int i = 0; i < _rows; i++)
	{
		for(int j = 0 ; j < _cols; j++)
		{
			_setMatrixCellData(i, j, ZERO);
		}
	}
}

Matrix::Matrix():  _rows(1), _cols(1),  _matrix(new float[1])
{
	_setMatrixCellData(ZERO, ZERO, ZERO);
}

Matrix::Matrix(const Matrix &other): _rows(other._rows), _cols(other._cols),
									_matrix(new float[other._rows * other._cols])
{
	for(int i = 0; i < _rows; i++)
	{
		for(int j = 0 ; j < _cols; j++)
		{
			_setMatrixCellData(i, j, other(i, j));
		}
	}
}

Matrix::~Matrix()
{
	delete[] _matrix;
}

int Matrix::getRows() const
{
	return _rows;
}

int Matrix::getCols() const
{
	return _cols;
}

Matrix& Matrix::vectorize()
{
	_rows = _cols * _rows;
	_cols = ONE;
	return *this;
}

Matrix &Matrix::operator = (const Matrix &other)
{
	if(this != &other)
	{
		delete[] _matrix;
		_rows = other._rows;
		_cols = other._cols;
		_matrix = new float[_rows * _cols];
		for(int i = 0; i < _rows; i++)
		{
			for(int j = 0 ; j < _cols; j++)
			{
				_setMatrixCellData(i, j, other(i, j));
			}
		}
	}
	return *this;
}

Matrix Matrix::operator * (const Matrix &rhsMatrix)
{
	Matrix result; // this will hold our result
	if(_rows == rhsMatrix.getCols() && _cols == rhsMatrix.getRows())
	{
		result = Matrix(_rows, rhsMatrix.getCols()); // this will hold our result
		for(int i = 0; i < _rows; i++)
		{
			for(int j = 0 ; j < rhsMatrix.getCols(); j++)
			{
				for(int k = 0 ; k < _rows; k++)
				{
					float newValue = (_matrix[_getIndex(i, k)] + rhsMatrix(k, j));
					result._setMatrixCellData(i, j, newValue);
				}
			}
		}
	}
	else
	{
		cout << "Error:  incorrect matrices dimensions" << endl;
		this->_exitWithError();
	}

	return(result);
}

Matrix& Matrix::operator * (const float c)
{
	for(int j = 0; j < _rows; j++)
	{
		for(int i = 0 ; i < _cols; i++)
		{
			float newValue = _matrix[_getIndex(j,i)] * c;
			_setMatrixCellData(i, j, newValue);
		}
	}
	return *this;
}

Matrix operator * (const float c, const Matrix &rhsMatrix)
{
	Matrix result = Matrix(rhsMatrix.getRows(), rhsMatrix.getCols()); // this will hold our result

	for(int j = 0; j < rhsMatrix.getRows(); j++)
	{
		for(int i = 0 ; i < rhsMatrix.getCols(); i++)
		{
			float newValue = rhsMatrix._matrix[rhsMatrix._getIndex(j,i)] * c;
			result._setMatrixCellData(i, j, newValue);
		}
	}
	return result;
}

void Matrix::_setMatrixCellData(const int r, const int c, const float data)
{
	int index = this->_getIndex(r,c);
	if(index != -1)
	{
		_matrix[index] = data;
	}
	else
	{
		_exitWithError();
	}
}

int Matrix::_getIndex(const int r, const int c) const
{
	if(this->_isValidIndex(r,c))
	{
		return r * _rows + c;
	}
	else
	{
		cout << "Error: out of range" << endl;
		exit(1);
	}
}

bool Matrix::_isValidIndex(const int r, const int c) const
{
	if(r > 0 && r <= _rows && c > 0 && c <= _cols)
	{
		return true;
	}
	return false;
}

void Matrix::_exitWithError()
{
	delete this;
	exit(1);
}

Matrix operator + (Matrix lhs, const Matrix &rhs)
{
	lhs += rhs; //reuse +=
	return lhs;
}

Matrix &Matrix::operator += (const Matrix &rhs)
{
	for (int i = 0; i < _rows; i++)
	{
		for (int j = 0; j < _cols; j++)
		{
			float newValue = (*this)(i,j) + rhs(i,j);
			_setMatrixCellData(i, j , newValue);
		}
	}
	return *this;
}

float& Matrix::operator() (const int r, const int c) const
{
	int index = _getIndex(r,c);
	return _matrix[index];
}

float& Matrix::operator [] (const int i) const
{
	return _matrix[i];
}

void Matrix::plainPrint() const
{
	const string SPACE = " ";
	for (int i = 0; i < _rows; i++)
	{
		for (int j = 0; j < _cols; j++)
		{
			cout << (*this)(i, j) << SPACE;
		}
		cout << endl;
	}
}

ostream &operator << (ostream &os, const Matrix &m)
{
	const float COMP_VALUE = 0.1;
	const string DONT_MARK = "  ", MARK = "**";
	for (int i = 0; i < m.getRows(); i++)
	{
		for (int j = 0; j < m.getCols(); j++)
		{
			if(m(i, j) <= COMP_VALUE)
			{
				os << DONT_MARK;
			}
			else
			{
				os << MARK;
			}
		}
		cout << endl;
	}
	return os;
}

istream& operator >> (istream& inStream, Matrix& m)
{
	const streamsize FLOAT_SIZE = sizeof(float);
	string str;
	char *floatS = nullptr;
	int index = ZERO;
	while (inStream.read(floatS, FLOAT_SIZE) && inStream.good())
	{
		string tempString(floatS);
		m[index] = stof(tempString);
		index++;
	}
	if(inStream.eof() == false)
	{
		cout << "Error:  couldn't fill the matrix from the stream" << endl;
		exit(1);
	}
	return inStream;
}

Matrix operator * (const Matrix &lhsMatrix, const Matrix &rhsMatrix)
{
	return lhsMatrix * rhsMatrix;
}

void Matrix::_setMatrixData(const float *arr, const int length)
{
	for(int i = 0 ; i < length; i++)
	{
		(*this)[i] = arr[i];
	}
}
