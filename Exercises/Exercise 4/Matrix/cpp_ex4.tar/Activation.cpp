//
// Created by BarM on 6/17/2020.
//

#include "Activation.h"

Activation::Activation(ActivationType actType): _actType(actType)
{

}

ActivationType Activation::getActivationType() const
{
	return _actType;
}

Matrix Activation::_relu(const Matrix &m) const
{
	Matrix newMatrix = Matrix(m);

	for(int i = 0 ; i < m.getRows(); i++)
	{
		if(newMatrix[i] < 0)
		{
			newMatrix[i] = 0;
		}
	}

	return newMatrix;
}

Matrix Activation::_softmax(const Matrix &m) const
{
	Matrix rightVector = Matrix(m);
	for(int i = 0 ; i < m.getRows(); i++)
	{
		rightVector[i] = exp(rightVector[i]);
	}

	float leftScalar = 0;
	for(int i = 0 ; i < m.getRows(); i++)
	{
		leftScalar += exp(m[i]);
	}

	if(leftScalar != 0)
	{
		leftScalar = 1 / leftScalar;
	}

	Matrix newMatrix = (leftScalar * rightVector);
	return newMatrix;
}

Matrix Activation::operator () (const Matrix& m) const
{
	Matrix newMatrix = Matrix(m);
	newMatrix.vectorize();
	if(_actType == RELU)
	{
		newMatrix = _relu(newMatrix);
	}
	else
	{
		newMatrix = _softmax(newMatrix);
	}

	return newMatrix;
}
