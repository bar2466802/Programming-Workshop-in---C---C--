//
// Created by BarM on 6/17/2020.
//

#include "MlpNetwork.h"

MlpNetwork::MlpNetwork(Matrix *weights, Matrix *biases)
{
	for(int i = 0 ; i < MLP_SIZE; i++)
	{
		ActivationType actType = Relu;
		if(i == FOURTH)
		{
			actType = Softmax;
		}
		_layers[i] = Dense(weights[i], biases[i], actType);
	}
}

Digit MlpNetwork::operator()(Matrix imgVec) const
{
	Matrix m = imgVec;
	for(int i = 0 ; i < MLP_SIZE; i++)
	{
		Matrix m = _layers[i](m);
	}
	Digit d = {0 , 0};
	for(int j = 0; j < m.getRows(); j++)
	{
		if(m[j] > d.probability)
		{
			d.probability = m[j];
			d.value = j;
		}
	}
	return d;
}
