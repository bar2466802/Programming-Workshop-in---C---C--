//
// Created by BarM on 6/17/2020.
//

#ifndef ACTIVATION_H
#define ACTIVATION_H

#include "Matrix.h"
#define RELU 0
#define SOFTMAX 1

/**
 * @enum ActivationType
 * @brief Indicator of activation function.
 */
enum ActivationType
{
	Relu,
	Softmax
};

class Activation
{
	private:
			ActivationType _actType;

			Matrix _relu(const Matrix& m) const;

			Matrix _softmax(const Matrix& m) const;
	public:
			/**
			* Constructor
			* Constructs Activation object with given actType
			* @param actType - activation type Relu / Softmax
			*/
			Activation(ActivationType actType);

			/**
			* Get the Activation's type
			* @return the actType
			*/
			ActivationType getActivationType() const;

			/**
			*  Redefine Parenthesis operator
			* @param m - the matrix to activate
			* @return new matrix after activation
			*/
			Matrix operator () (const Matrix& m) const;
};

#endif //ACTIVATION_H
