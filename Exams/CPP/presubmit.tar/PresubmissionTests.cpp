#include "helpers/Presubmit.hpp"

int main() {
    return runPreSubmissionChecks() ? EXIT_SUCCESS : EXIT_FAILURE;
}